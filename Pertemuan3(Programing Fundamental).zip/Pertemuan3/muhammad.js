let tinggi = 3;

for (let i = tinggi; i >= 1; i--) {
        console.log(" ".repeat(tinggi - i) + "*".repeat(i));
    }
